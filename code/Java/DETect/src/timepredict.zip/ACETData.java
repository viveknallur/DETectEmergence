public class ACETData
{
	//Details for the large array
	int[] acetArray;
	double min, increment;
	int size, index, capacity;
	boolean wrapped;

	//Details for the lag length array
	double[] lagLength;
	int lagSize, lagIndex, lagCapacity;
	double lagAverage, lagStdDev;
	boolean lagWrapped;


	public ACETData()
	{
		lagWrapped = false;
		lagIndex = 0;
		lagSize = 0;
		lagCapacity = 50;
		lagLength = new double[lagCapacity];
	}



	public void addMeasurement(double measurement)
	{
		addLagMeasurement(measurement);
	}


	/**
	 * Adds the latest value to the lag length array. This function
	 * replaces the oldest value with the most recent if already
	 * filled.
	 *
	 * @param measurement The double value measurement to be added.
	 */
	private void addLagMeasurement(double measurement)
	{
		lagLength[lagIndex] = measurement;
		lagIndex++;

		if(!wrapped)
		{
			if(lagIndex == lagCapacity)
			{
				lagSize = lagCapacity;
				lagIndex = 0;
				wrapped = true;
				generateLagStats();
			}
			else
			{
				lagSize++;
				generateLagStats();
			}
		}
		else
		{
			if(lagIndex == lagCapacity)
			{
				lagIndex = 0;
				updateLagStats();
			}
		}
	}

	/**
	 * This function generates the moving average and the
	 * standard deviation of the lag length values, when
	 * the array is not yet full. Otherwise the updateLagStats
	 * function is used.
	 */
	public void generateLagStats()
	{
		double total = 0.0;
		double n = (double) lagSize;

		for(int i=0; i<lagSize; i++)
		{
			total += lagLength[i];
		}
		
		lagAverage = total/n;
		total = 0.0;

		for(int i=0; i<lagSize; i++)
		{
			total += Math.pow((lagLength[i]-lagAverage),2.0);
		}

		lagStdDev = Math.sqrt((1.0/n-1.0)*total);
	}


	public void updateLagStats()
	{

	}


	/**
	 * This function is used to check the lag size of the
	 * current lag length array.
	 *
	 * @return An int representing the current size
	 */
	public int getLagSize() {
		return lagSize;
	}

	/**
	 * This function resizes the lag length array. In the case
	 * where the array is decreased from its previous size, the
	 * previous n measurements are stored, and older ones discarded.
	 *
	 * @param lagCapacity The new capacity of the lag array
	 */
	public void setLagCapacity(int lagCapacity)
	{
		this.lagCapacity = lagCapacity;

		if(lagSize == 0)
		{
			lagLength = new double[lagCapacity];
		}
		//Increase array
		else if(lagCapacity > lagSize)
		{
			double temp[] = new double[lagCapacity];
			System.arraycopy(lagLength, 0, temp, 0, lagLength.length);
			lagLength = new double[lagCapacity];
			System.arraycopy(temp, 0, lagLength, 0, lagCapacity);
		}
		//Decrease array
		else if (lagCapacity < lagSize)
		{
			double temp[] = new double[lagCapacity];
			for(int i=0; i<lagCapacity; i++)
			{
				temp[i] = getPrevMeasurement(i);
			}
			lagLength = new double[lagCapacity];
			System.arraycopy(temp, 0, lagLength, 0, lagCapacity);
		}
	}


	/**
	 * This function does a backwards lookup on the array to return
	 * the previous measurement(s). The zero element specified in the
	 * input parameters is the most recent measurement, whereas the
	 * n measurement is the nth most recent measurement. If no element
	 * exists for the specified position, a -1.0 value is returned.
	 *
	 * @param i The ith previous measurement that is requested.
	 * @return A double value taken from the array.
	 */
	public double getPrevMeasurement(int i)
	{
		double result = -1.0;

		if(i < lagSize)
		{
			int position = lagIndex -1 - i;

			if(position < 0)
			{
				position = lagLength.length + lagIndex - 1 - i;
			}

			result = lagLength[position];
		}
		else
		{
			System.err.println("Can't retrieve previous array element where prev > size");
		}

		return result;
	}

	/**
	 * This function is used to check the capacity of the
	 * current lag length array.
	 *
	 * @return An int representing the current capacity of the array
	 */
	public int getLagCapacity() {
		return lagCapacity;
	}


	/**
	 * Function to check if the lag length array has wrapped around
	 * on itself.
	 *
	 * @return True if the array is wrapped, false otherwise.
	 */
	public boolean isLagWrapped() {
		return lagWrapped;
	}


	/**
	 * This function returns the moving average of the
	 * elements currently stored in the lag length array.
	 *
	 * @return A double value giving the moving average.
	 */
	public double getLagAverage() {
		return lagAverage;
	}


	/**
	 * The standard deviation of the values stored in the
	 * lag length array.
	 *
	 * @return A double value giving the standard deviation.
	 */
	public double getLagStdDev() {
		return lagStdDev;
	}


	/**
	 * Prints out the values within the array and their
	 * index positions.
	 */
	public void printLagLength()
	{
		for(int i=0; i<lagLength.length; i++)
		{
			if(i == lagIndex)
			{
				System.out.println("["+i+"] \t "+lagLength[i]+" <- Index");
			}
			else
			{
				System.out.println("["+i+"] \t "+lagLength[i]);
			}
		}
	}
}
