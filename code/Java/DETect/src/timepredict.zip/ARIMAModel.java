public class ARIMAModel {

	int p, q;								//Regression limiters
	int n;									//The number of estimates

	double alpha, beta, gamma;				//The parameters

	double xnLower, xnUpper;				//The previous timing estimate

	double accuracyTotal, precisionTotal;	//Accuracy and Precision totals
	double accuracy, precision;				//Accuracy and Precision averages

	ACETData acetData;

	public ARIMAModel(ACETData acetData)
	{
		this.acetData = acetData;

		//Initialise the alpha, beta, gamma parameters
		initParameters();
		initAccuracy();
	}


	private void initParameters()
	{
		alpha = 0.9;
		beta = 0.9;
		gamma = 0.9;
	}

	private void initAccuracy()
	{
		accuracyTotal = 0.0;
		precisionTotal = 0.0;
		n = 0;
		accuracy = 0.0;
		precision = 0.0;
	}

	/**
	 * The getEstimate function takes as a argument the previous timing
	 * measurement, and generates an estimate based on this (as well
	 * as the previous behaviour of the estimation process).
	 *
	 * @return An array of size two giving the upper and lower estimate bounds.
	 */
	public double[] getEstimate()
	{
		double[] result = new double[2];

		//Get the previous measurement
		double measurement = acetData.getPrevMeasurement(0);

		//Updates the accuracy and precision metrics
		updateAccuracy(measurement);

		//Get the size and lag length
		int lagSize = acetData.getLagSize();
		int lagLength = acetData.getLagCapacity();

		//If there's no existing timing measurements, return max
		if(lagSize == 0)
		{
			result[0] = Double.MIN_VALUE;
			result[1] = Double.MAX_VALUE;
			logError("getEstimate", "No measurements available to generate estimate");
		}
		else if(lagSize == 1)
		{
			result[0] = measurement;
			result[1] = measurement;
			xnLower = result[0];
			xnUpper = result[1];
		}
		else if(lagSize == 2)
		{
			result[0] = (alpha*measurement) - ((1-alpha)*xnLower);
			result[1] = (alpha*measurement) + ((1-alpha)*xnUpper);
			xnLower = result[0];
			xnUpper = result[1];
		}
		//Start the ARIMA stuff now
		else
		{
			//If there's less terms than specified by the lag length
			if(lagSize < lagLength)
			{
				p = lagSize;
				q = lagSize;
			}
			//If there's exactly the lag length in there
			else
			{
				p = lagLength;
				q = lagLength;
			}

			double arWeight, maWeight;
			double arTerm = 0.0;
			double maTerm = 0.0;
			double total  = 0.0;
			double num = 0.0;
			double mean, stdDev;

			for(int i=0; i<p; i++)
			{
				arWeight = getWeight(i, p);
				arTerm += (acetData.getPrevMeasurement(i))*arWeight;
				total += acetData.getPrevMeasurement(i);
				num += 1.0;
			}

			mean = total/num;
			total = 0.0;

			for(int i=0; i<q; i++)
			{
				maWeight = getWeight(i, q);
				maTerm += (acetData.getPrevMeasurement(i)-mean)*maWeight;
				total += Math.pow((acetData.getPrevMeasurement(i)-mean), 2.0);
			}

			stdDev = Math.pow((total/(num-1)), 0.5);

			//System.out.println("ARTERM: "+arTerm);
			//System.out.println("MATERM: "+maTerm);
			//System.out.println("STDDEV: "+stdDev);

			result[0] = Math.floor(arTerm + maTerm - (2*stdDev));
			result[1] = Math.ceil(arTerm + maTerm + (2*stdDev));
		}

		//Increment the number of estimates
		n++;

        //Make sure no nonsense values are returned
        if(result[0] < 0.0)
        {
            result[0] = 0.0;
        }

		return result;
	}

	/**
	 * This function returns the value for a weighting parameter as a
	 * decreasing curve, so that the integral under the curve adds to
	 * 1.0. This is required to weight the values in a moving average
	 * sequence such that the most recent values are highlighted more
	 * than previous ones.
	 *
	 * @param limit The p or q value that considers the number of terms.
	 * @return The value for alpha in the equation 1 = integral (e^{-alpha*limit})
	 */
    public double getWeight(double x, double limit)
    {
        double denom = 0.25*(Math.pow(limit, 2.0))*(Math.pow(limit+1, 2.0));
        double result = (Math.pow(limit-x, 3.0))/denom;
        return result;
    }

    /**
     * This function is used to check that the sum of the weights up to
     * the limit actually equals 1.0 (or comes very near to it).
     *
     * @param limit The number of terms to be considered
     * @return The sum of the weightings up to those terms.
     */
    public double sumWeights(double limit)
    {
        double x = 0.0;
        double sum = 0.0;

        while(x <= limit)
        {
            sum += getWeight(x, limit);
            x += 1.0;
        }

        System.out.println("Sum: "+sum);

        return sum;
    }

    private void updateAccuracy(double measurement)
    {
    	if((xnLower <= measurement)&&(measurement >= xnUpper))
    	{
    		accuracyTotal += 1.0;
    	}

    	precisionTotal += Math.abs(xnLower-measurement);
    	precisionTotal += Math.abs(xnUpper-measurement);

    }

	public double getAccuracy() {
		accuracy = accuracyTotal/(double) n;
		return accuracy;
	}


	public double getPrecision() {
		precision = precisionTotal/(double) n;
		return precision;
	}


	/**
	 * This private function is used to highlight an error
	 * that may occur within the class. Although this error
	 * can be logged, by default it is set to print to the
	 * command-line.
	 *
	 * @param method The originating method
	 * @param error The error text
	 */
	private void logError(String method, String error)
	{
		System.err.println("ARIMAModel:"+method+":"+error);
	}
}
