public class GEVModel
{
	private WCETData wcetData;

	private double[] weibullModel;
	private double weibullAlpha, weibullFit;
	private double weibullAlphaInc;

	private double[] frechetModel;
	private double frechetAlpha, frechetFit;
	private double frechetAlphaInc;

	private double[] paretoModel;
	private double paretoAlpha, paretoFit;
	private double paretoAlphaInc;

	private double[] gumbelModel;
	private double gumbelFit;

	private double[] dataCDF;
	private double[] dataParetoCDF;
	private String selectedDistribution;

	public final static String gumbelType = "GUMBEL";
	public final static String weibullType = "WEIBULL";
	public final static String frechetType = "FRECHET";
	public final static String paretoType = "PARETO";


	public GEVModel(WCETData wcetData)
	{
		this.wcetData = wcetData;
		selectedDistribution = weibullType;
	}


	public String getSelectedDistribution()
	{
		return selectedDistribution;
	}

	public void setSelectedDistribution(String type)
	{
		selectedDistribution = type;
	}


	public double getEstimate()
	{
		getDataCDF();

		//Fit the models
		fitWeibull();
		//fitFrechet();
		//fitGumbel();
		//fitPareto();


		//Test which fit is best



		//Get the estimate
		double weibullEst = this.getWeibullEstimate(0.9);
		//double frechetEst = this.getFrechetEstimate(0.9);
		//double paretoEst = this.getParetoEstimate(0.9);
		//double gumbelEst = this.getGumbelEstimate(0.9);

		//return gumbelEst;
		//return paretoEst;
		return weibullEst;
		//return frechetEst;
	}


	private void getDataCDF()
	{
		wcetData.updateData();

		dataCDF = new double[6];
		dataCDF[0] = wcetData.getMeasurementCDF(0.0);
		dataCDF[1] = wcetData.getMeasurementCDF(0.15);
		dataCDF[2] = wcetData.getMeasurementCDF(0.30);
		dataCDF[3] = wcetData.getMeasurementCDF(0.45);
		dataCDF[4] = wcetData.getMeasurementCDF(0.60);
		dataCDF[5] = wcetData.getMeasurementCDF(0.75);

		dataParetoCDF = new double[6];
		dataParetoCDF[0] = wcetData.getParetoCDF(0.0);
		dataParetoCDF[1] = wcetData.getParetoCDF(0.15);
		dataParetoCDF[2] = wcetData.getParetoCDF(0.30);
		dataParetoCDF[3] = wcetData.getParetoCDF(0.45);
		dataParetoCDF[4] = wcetData.getParetoCDF(0.60);
		dataParetoCDF[5] = wcetData.getParetoCDF(0.75);
	}

//=========================== GUMBEL DISTRIBUTION ========================


	private void fitGumbel()
	{
		double xScale = 0.0;
		xScale += (dataCDF[1]-dataCDF[0])/(getGumbelCDF(0.15,1.0)-getGumbelCDF(0.0, 1.0));
		xScale += (dataCDF[2]-dataCDF[1])/(getGumbelCDF(0.30,1.0)-getGumbelCDF(0.15,1.0));
		xScale += (dataCDF[3]-dataCDF[2])/(getGumbelCDF(0.45,1.0)-getGumbelCDF(0.30,1.0));
		xScale += (dataCDF[4]-dataCDF[3])/(getGumbelCDF(0.60,1.0)-getGumbelCDF(0.45,1.0));
		xScale += (dataCDF[5]-dataCDF[4])/(getGumbelCDF(0.75,1.0)-getGumbelCDF(0.60,1.0));
		xScale = xScale/5.0;

		double distMin = getGumbelCDF(0.0,1.0);
		double fit = 0.0;

        for (double prob = 0.01; prob < 0.99; prob += 0.1)
        {
            double distX = ((getGumbelCDF(prob, 1.0) - distMin) * xScale) + dataCDF[0];
            double dataX = wcetData.getMeasurementCDF(prob);
            fit += Math.pow((distX - dataX), 2);
        }

        gumbelFit = fit;
	}

	private double getGumbelEstimate(double confidence)
	{
		double xScale = 0.0;
		xScale += (dataCDF[1]-dataCDF[0])/(getGumbelCDF(0.15,1.0)-getGumbelCDF(0.0, 1.0));
		xScale += (dataCDF[2]-dataCDF[1])/(getGumbelCDF(0.30,1.0)-getGumbelCDF(0.15,1.0));
		xScale += (dataCDF[3]-dataCDF[2])/(getGumbelCDF(0.45,1.0)-getGumbelCDF(0.30,1.0));
		xScale += (dataCDF[4]-dataCDF[3])/(getGumbelCDF(0.60,1.0)-getGumbelCDF(0.45,1.0));
		xScale += (dataCDF[5]-dataCDF[4])/(getGumbelCDF(0.75,1.0)-getGumbelCDF(0.60,1.0));
		xScale = xScale/5.0;
		double distMin = getGumbelCDF(0.0,1.0);
		double distX = ((getGumbelCDF(confidence, 1.0) - distMin) * xScale) + dataCDF[0];
        return distX;
	}


	/**
	 * The same function for the Gumbel distribution, i.e., convert
	 * f(x) to x.
	 *
	 * @param y The probability, 0.0 to 1.0
	 * @param scale The scale value for the distribution (Gumbel has no alpha parameter).
	 * @return The x-axis corresponding to the probability.
	 */
    private double getGumbelCDF(double y, double scale)
    {
    	double result;
    	if(y == 0)
    	{
    	 	result = -1*scale*Math.log(-1*Math.log(0.00001));
    	}
    	else if(y == 1.0)
    	{
    	 	result = -1*scale*Math.log(-1*Math.log(0.99999));
    	}
    	else
    	{
    	 	result = -1*scale*Math.log(-1*Math.log(y));
    	}
    	return result;
    }

//=========================== PARETO DISTRIBUTION ========================

	private void fitPareto()
	{
		//0.367879441 equals 1 on x-axis
		double startAlpha = 1.0;
		double endAlpha = 50.0;
		paretoAlphaInc = 0.001;
		paretoAlpha = fitPareto(startAlpha, endAlpha);
	}


	private double fitPareto(double min, double max)
	{
		double alpha = (max+min)/2.0;

		if((min+paretoAlphaInc) > max)
		{
			return alpha;
		}
		else
		{
			double lowerFit = fitPareto((alpha+min)/2.0);
			double upperFit = fitPareto(alpha+max/2.0);

			//System.err.println("Alphas:"+min+"\t"+alpha+"\t"+max);
			//System.err.println("Fits:"+lowerFit+"\t"+upperFit);
			//sleep(500);

			if(lowerFit < upperFit)
			{
				paretoFit = lowerFit;
				return fitPareto(min, alpha);
			}
			else
			{
				paretoFit = upperFit;
				return fitPareto(alpha, max);
			}
		}
	}

	private double fitPareto(double alpha)
	{
		double xScale = 0.0;
		xScale += (dataParetoCDF[1]-dataParetoCDF[0])/(getParetoCDF(0.15,alpha)-getParetoCDF(0.0,alpha));
		xScale += (dataParetoCDF[2]-dataParetoCDF[1])/(getParetoCDF(0.30,alpha)-getParetoCDF(0.15,alpha));
		xScale += (dataParetoCDF[3]-dataParetoCDF[2])/(getParetoCDF(0.45,alpha)-getParetoCDF(0.30,alpha));
		xScale += (dataParetoCDF[4]-dataParetoCDF[3])/(getParetoCDF(0.60,alpha)-getParetoCDF(0.45,alpha));
		xScale += (dataParetoCDF[5]-dataParetoCDF[4])/(getParetoCDF(0.75,alpha)-getParetoCDF(0.60,alpha));
		xScale = xScale/5.0;

		double distMin = getParetoCDF(0.0,alpha);
		double fit = 0.0;

        for (double prob = 0.01; prob < 0.99; prob += 0.1)
        {
            double distX = ((getParetoCDF(prob, alpha) - distMin) * xScale) + dataCDF[0];
            double dataX = wcetData.getParetoCDF(prob);
            fit += Math.pow((distX - dataX), 2);
        }

        return fit;
	}


	private double getParetoEstimate(double confidence)
	{
		double xScale = 0.0;
		xScale += (dataParetoCDF[1]-dataParetoCDF[0])/(getParetoCDF(0.15,paretoAlpha)-getParetoCDF(0.0,paretoAlpha));
		xScale += (dataParetoCDF[2]-dataParetoCDF[1])/(getParetoCDF(0.30,paretoAlpha)-getParetoCDF(0.15,paretoAlpha));
		xScale += (dataParetoCDF[3]-dataParetoCDF[2])/(getParetoCDF(0.45,paretoAlpha)-getParetoCDF(0.30,paretoAlpha));
		xScale += (dataParetoCDF[4]-dataParetoCDF[3])/(getParetoCDF(0.60,paretoAlpha)-getParetoCDF(0.45,paretoAlpha));
		xScale += (dataParetoCDF[5]-dataParetoCDF[4])/(getParetoCDF(0.75,paretoAlpha)-getParetoCDF(0.60,paretoAlpha));
		xScale = xScale/5.0;
		double distMin = getParetoCDF(0.0,paretoAlpha);
		double distX = ((getParetoCDF(confidence, paretoAlpha) - distMin) * xScale) + dataParetoCDF[0];
        return distX;
	}


	/**
	 * The same function for the Pareto distribution, i.e., convert
	 * f(x) to x.
	 *
	 * @param y The probability, 0.0 to 1.0
	 * @param alpha The alpha value of the distribution.
	 * @return The x-axis corresponding to the probability.
	 */
    private double getParetoCDF(double y, double alpha) {
        double x = 1 / Math.pow((1 - y), (1 / alpha));
        return x;
    }

//========================== FRECHET DISTRIBUTION ==========================

	public void fitFrechet()
	{
		//0.367879441 equals 1 on x-axis
		double startAlpha = 1.0;
		double endAlpha = 50.0;
		frechetAlphaInc = 0.001;
		frechetAlpha = fitFrechet(startAlpha, endAlpha);

	}

	private double fitFrechet(double min, double max)
	{
		double alpha = (max+min)/2.0;

		if((min+frechetAlphaInc) > max)
		{
			return alpha;
		}
		else
		{
			double lowerFit = fitFrechet((alpha+min)/2.0);
			double upperFit = fitFrechet(alpha+max/2.0);

			//System.err.println("Alphas:"+min+"\t"+alpha+"\t"+max);
			//System.err.println("Fits:"+lowerFit+"\t"+upperFit);
			//sleep(500);

			if(lowerFit < upperFit)
			{
				frechetFit = lowerFit;
				return fitFrechet(min, alpha);
			}
			else
			{
				frechetFit = upperFit;
				return fitFrechet(alpha, max);
			}
		}
	}


	private double fitFrechet(double alpha)
	{
		double xScale = 0.0;
		xScale += (dataCDF[1]-dataCDF[0])/(getFrechetCDF(0.15,alpha)-getFrechetCDF(0.0,alpha));
		xScale += (dataCDF[2]-dataCDF[1])/(getFrechetCDF(0.30,alpha)-getFrechetCDF(0.15,alpha));
		xScale += (dataCDF[3]-dataCDF[2])/(getFrechetCDF(0.45,alpha)-getFrechetCDF(0.30,alpha));
		xScale += (dataCDF[4]-dataCDF[3])/(getFrechetCDF(0.60,alpha)-getFrechetCDF(0.45,alpha));
		xScale += (dataCDF[5]-dataCDF[4])/(getFrechetCDF(0.75,alpha)-getFrechetCDF(0.60,alpha));
		xScale = xScale/5.0;

		double distMin = getFrechetCDF(0.0,alpha);
		double fit = 0.0;

        for (double prob = 0.01; prob < 0.99; prob += 0.1)
        {
            double distX = ((getFrechetCDF(prob, alpha) - distMin) * xScale) + dataCDF[0];
            double dataX = wcetData.getMeasurementCDF(prob);
            fit += Math.pow((distX - dataX), 2);
        }

        return fit;
	}

	private double getFrechetEstimate(double confidence)
	{
		double xScale = 0.0;
		xScale += (dataCDF[1]-dataCDF[0])/(getFrechetCDF(0.15,frechetAlpha)-getFrechetCDF(0.0,frechetAlpha));
		xScale += (dataCDF[2]-dataCDF[1])/(getFrechetCDF(0.30,frechetAlpha)-getFrechetCDF(0.15,frechetAlpha));
		xScale += (dataCDF[3]-dataCDF[2])/(getFrechetCDF(0.45,frechetAlpha)-getFrechetCDF(0.30,frechetAlpha));
		xScale += (dataCDF[4]-dataCDF[3])/(getFrechetCDF(0.60,frechetAlpha)-getFrechetCDF(0.45,frechetAlpha));
		xScale += (dataCDF[5]-dataCDF[4])/(getFrechetCDF(0.75,frechetAlpha)-getFrechetCDF(0.60,frechetAlpha));
		xScale = xScale/5.0;
		double distMin = getFrechetCDF(0.0,frechetAlpha);
		double distX = ((getFrechetCDF(confidence, frechetAlpha) - distMin) * xScale) + dataCDF[0];
        return distX;
	}

	/**
	 * This function gives the x axis value for the specified f(x) value.
	 *
	 * @param y The probability, 0.0 to 1.0
	 * @param alpha The alpha value of the distribution.
	 * @return The x-axis corresponding to the probability.
	 */
	public double getFrechetCDF(double y, double alpha)
	{
		double result = Math.pow( ( -1 * Math.log(y)), -1/alpha);
		return result;
	}

//============================== WEIBULL ===================================

	private void fitWeibull()
	{
		//0.632120559 equals 1 on x-axis
		double startAlpha = 0.01;
		double endAlpha = 50.0;
		weibullAlphaInc = 0.0001;
		weibullAlpha = fitWeibull(startAlpha, endAlpha);
	}

	private double fitWeibull(double min, double max)
	{
		double alpha = (max+min)/2.0;

		if((min+weibullAlphaInc) > max)
		{
			return alpha;
		}
		else
		{
			double lowerFit = fitWeibull((alpha+min)/2.0);
			double upperFit = fitWeibull(alpha+max/2.0);

			if(lowerFit < upperFit)
			{
				weibullFit = lowerFit;
				return fitWeibull(min, alpha);
			}
			else
			{
				weibullFit = upperFit;
				return fitWeibull(alpha, max);
			}
		}
	}

	private double fitWeibull(double alpha)
	{
		double xScale = 0.0;
		xScale += (dataCDF[1]-dataCDF[0])/(getWeibullCDF(0.15,alpha)-getWeibullCDF(0.0,alpha));
		xScale += (dataCDF[2]-dataCDF[1])/(getWeibullCDF(0.30,alpha)-getWeibullCDF(0.15,alpha));
		xScale += (dataCDF[3]-dataCDF[2])/(getWeibullCDF(0.45,alpha)-getWeibullCDF(0.30,alpha));
		xScale += (dataCDF[4]-dataCDF[3])/(getWeibullCDF(0.60,alpha)-getWeibullCDF(0.45,alpha));
		xScale += (dataCDF[5]-dataCDF[4])/(getWeibullCDF(0.75,alpha)-getWeibullCDF(0.60,alpha));
		xScale = xScale/5.0;

		double distMin = getWeibullCDF(0.0,alpha);
		double fit = 0.0;

        for (double prob = 0.01; prob < 0.99; prob += 0.1)
        {
            double distX = ((getWeibullCDF(prob, alpha) - distMin) * xScale) + dataCDF[0];
            double dataX = wcetData.getMeasurementCDF(prob);
            fit += Math.pow((distX - dataX), 2);
        }

        return fit;
	}


	private double getWeibullEstimate(double confidence)
	{
		double xScale = 0.0;
		xScale += (dataCDF[1]-dataCDF[0])/(getWeibullCDF(0.15,weibullAlpha)-getWeibullCDF(0.0,weibullAlpha));
		xScale += (dataCDF[2]-dataCDF[1])/(getWeibullCDF(0.30,weibullAlpha)-getWeibullCDF(0.15,weibullAlpha));
		xScale += (dataCDF[3]-dataCDF[2])/(getWeibullCDF(0.45,weibullAlpha)-getWeibullCDF(0.30,weibullAlpha));
		xScale += (dataCDF[4]-dataCDF[3])/(getWeibullCDF(0.60,weibullAlpha)-getWeibullCDF(0.45,weibullAlpha));
		xScale += (dataCDF[5]-dataCDF[4])/(getWeibullCDF(0.75,weibullAlpha)-getWeibullCDF(0.60,weibullAlpha));
		xScale = xScale/5.0;
		double distMin = getWeibullCDF(0.0,weibullAlpha);
		double distX = ((getWeibullCDF(confidence, weibullAlpha) - distMin) * xScale) + dataCDF[0];
        return distX;
	}

	/**
	* This function returns the point on the x-axis of the Weibull cumulative
	* density function that gives the cumulative probability y. This funciton is
	* used to provide the extreme range of the distribution to allow the data
	* histogram to be scaled to match.
	*
	*/
	double getWeibullCDF(double y, double alpha)
	{
		if(alpha == 1)
		{
			return (-1 * Math.log(1-y));
		}
		else
		{
			double result = Math.pow( (-1 * Math.log(1-y)), 1/alpha);
			return result;
		}
	}


//================================ OTHER FUNCTIONS =========================

    private void sleep(long time)
    {
    	try
    	{
    		Thread.sleep(time);
    	}
    	catch(Exception ex)
    	{
    		ex.printStackTrace();
    	}
    }

    private void printFittedWeibullCDF()
    {
    	for(double i=0.0; i<0.99; i+=0.01)
    	{
    		double x = this.getWeibullEstimate(i);
    		System.out.println(x+"\t"+i);
    	}
    }
}
