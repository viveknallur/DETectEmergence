public class ESModel {
	double tn1, tn2, tn3;					//T(n-1), T(n-2) etc.
	double lowerXn, upperXn;				//The timing estimates upper and lower
	double Xn, Sn, Rn;						//The timing and trend info
	double lowerEn, upperEn;				//The upper and lower error

	double alpha, beta, gamma;				//The smoothing factors

	int n;									//Accuracy per num. requests
	double accuracyTotal, precisionTotal;	//Accuracy and Precision totals
	double accuracy, precision;				//Accuracy and Precision averages

	ACETData acetData;

	/**
	 * The constructor sets the alpha, beta and gamma parameters, and
	 * initializes the accuracy and precision variables.
	 */
	public ESModel(ACETData acetData)
	{
		//The smoothing factors
		alpha = 0.9;
		beta = 0.9;
		gamma = 0.9;

		//The base cases
		lowerEn = 0.0;
		upperEn = 0.0;
		Rn = 0.0;

		accuracyTotal = 0.0;
		precisionTotal = 0.0;
		accuracy = 1.0;
		precision = Double.MAX_VALUE;
		n = 0;

		//Set the connection to the ACET data store
		this.acetData = acetData;
	}

	/**
	 * This function resets all the parameters to their default
	 * value on the occurrence of an adaptation.
	 */
	public void signalAdaptation()
	{
		//The smoothing factors
		alpha = 0.9;
		beta = 0.9;
		gamma = 0.9;

		//The base cases
		lowerEn = 0.0;
		upperEn = 0.0;
		Rn = 0.0;

		accuracyTotal = 0.0;
		precisionTotal = 0.0;
		accuracy = 1.0;
		precision = Double.MAX_VALUE;
	}

	/**
	 * The getEstimate function takes as a argument the previous timing
	 * measurement, and generates an estimate based on this (as well
	 * as the previous behaviour of the estimation process).
	 *
	 * @param measurement The timing measurement
	 * @return An array of size two giving the upper and lower estimate bounds.
	 */
	public double[] getEstimate()
	{
		double[] result = new double[2];
		double tn = acetData.getPrevMeasurement(0);

		if(n == 0)
		{
			result[0] = tn - (tn/2);
			result[1] = tn + (tn/2);
			Sn = (double) tn;
			Xn = (double) tn;
			Rn = 0.0;
			lowerEn = 0.0;
			upperEn = 0.0;
			lowerXn = (double) result[0];
			upperXn = (double) result[1];
			tn1 = tn;
		}
		else if(n == 1)
		{
			Sn = (alpha*tn) + ((1-alpha)*Xn);
			Rn = 0.0;

			//Sort out the error bounds
			double error = (double) tn-tn1;
			error = Math.abs(error);
			lowerEn = error;
			upperEn = error;

			//Update the measurements
			tn3 = tn1;						//Cheat to instantiate tn3 early
			tn2 = tn1;
			tn1 = tn;
		}
		else
		{
			//Check the accuracy of the previous estimate
			refreshAccuracy(tn);

			Sn = (alpha*tn) + ((1-alpha)*Xn);
			Rn = 0.0;

			//If the measurement exceeded the lower bounds
			if(tn < lowerXn)
			{
				//lowerEn = gamma*(lowerXn-tn) + (1-gamma)*lowerEn;
				lowerEn = gamma*(Math.abs(tn1-tn)+(tn-lowerXn)) + (1-gamma)*lowerEn;

			}
			else if( ((lowerXn-tn) < (1-gamma)*(tn1-tn)) && ((tn1-tn) > 0))
			{
				//lowerEn = gamma*((tn1-tn)+(lowerXn-tn)) + (1-gamma)*lowerEn;
				lowerEn = gamma*lowerEn + (1-gamma)*(tn1-tn);
			}
			else
			{
				lowerEn = gamma*lowerEn;
			}

			lowerEn = Math.ceil(lowerEn);

			//Sort out the upper error bounds
			if(tn > upperXn)
			{
				//upperEn = gamma*(tn-upperXn) + (1-gamma)*upperEn;
				upperEn = gamma*(Math.abs(tn-tn1)+(tn-upperXn)) + (1-gamma)*upperEn;

			}
			else if( ((upperXn-tn) < (1-gamma)*(tn-tn1)) && ((tn-tn1) > 0) )
			{
				//upperEn = gamma*((tn-tn1)+(upperXn-tn)) + (1-gamma)*upperEn;
				upperEn = gamma*upperEn+ (1-gamma)*(tn-tn1);
			}
			else
			{
				upperEn = gamma*upperEn;
			}

			lowerEn = Math.ceil(upperEn);


			tn3 = tn2;
			tn2 = tn1;
			tn1 = tn;
		}


		//Increment the measurement count
		n++;

		//Calculate result
		result[0] = Math.floor(Sn + Rn - lowerEn);
		result[1] = Math.ceil(Sn + Rn + upperEn);

        if(result[0] < 0.0)
        {
            result[0] = 0.0;
        }

		//Update metrics
		Xn = Sn + Rn;
		lowerXn = result[0];
		upperXn = result[1];

		return result;
	}




	public void refreshAccuracy(double measurement)
	{
		if((lowerXn <= measurement)&&(measurement <= upperXn))
		{
			//System.out.println(lowerXn+"\t"+measurement+"\t"+upperXn+"\tPASS");
			accuracyTotal += 1.0;
			precisionTotal += Math.abs(lowerXn-measurement);
			precisionTotal += Math.abs(upperXn-measurement);
			accuracy = accuracyTotal/(double) n;
			precision = precisionTotal/(double) n;
		}
		else
		{
			//System.out.println(lowerXn+"\t"+measurement+"\t"+upperXn+"\tFAIL");
			precisionTotal += Math.abs(lowerXn-measurement);
			precisionTotal += Math.abs(upperXn-measurement);
			accuracy = accuracyTotal/(double) n;
			precision = precisionTotal/(double) n;
		}
	}

	public double getAccuracy()
	{
		return accuracy;
	}

	public double getPrecision()
	{
		return precision;
	}

	public void printAccuracy()
	{
		System.out.println("Accuracy: "+accuracy);
		System.out.println("Precision: "+precision);
	}
}
