public class HeuristicWCET {

	WCETData wcetData;			//The class containing all the WCET data

	public HeuristicWCET(WCETData wcetData)
	{
		this.wcetData = wcetData;
	}

	public double getEstimate()
	{
		double coefficient = wcetData.getExceededRatio();
		double w = wcetData.getQuartile(4);
		double result = (coefficient*w);
		return result;
	}

}
