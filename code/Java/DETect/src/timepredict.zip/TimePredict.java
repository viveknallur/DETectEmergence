public class TimePredict
{
	private ACETData acetData;
	private WCETData wcetData;
	private ESModel esModel;
	private GEVModel gevModel;
	private ARIMAModel arimaModel;
	private HeuristicWCET heuristicWCET;

	//The limits used to update (or not) TimePredict
	private boolean levelUpdate;
	private double[] updateACET;
	private double updateWCET;

	//The estimates
	private double[] esEst, arimaEst;
	private double heurEst, gevEst;

	private double accES, accARIMA, accHEUR, accGEV;
	private double precES, precARIMA, precHEUR, precGEV;

	private double prevMeasurement;
	private boolean printEstimates;

	public TimePredict()
	{
		acetData = new ACETData();
		wcetData = new WCETData();
		esModel = new ESModel(acetData);
		arimaModel = new ARIMAModel(acetData);
		heuristicWCET = new HeuristicWCET(wcetData);
		gevModel = new GEVModel(wcetData);

		levelUpdate = false;
		updateACET = new double[2];
		updateWCET = 0.0;

		//The simulator for testing
		printEstimates = false;
		prevMeasurement = -1.0;
	}


	public void addMeasurement(double measurement)
	{
		acetData.addMeasurement(measurement);
		wcetData.addMeasurement(measurement);

		if(!levelUpdate)
		{
			updateEstimates();
		}
		else if(isOutsideBounds(measurement))
		{
			updateEstimates();
		}

		prevMeasurement = measurement;
	}

	public void updateEstimates()
	{
		esEst = esModel.getEstimate();
		arimaEst = arimaModel.getEstimate();
		heurEst = heuristicWCET.getEstimate();
		gevEst = gevModel.getEstimate();

		if(printEstimates)
		{
			System.out.print(prevMeasurement);
			System.out.print("\t"+esEst[0]+"\t"+esEst[1]);
			System.out.print("\t"+arimaEst[0]+"\t"+arimaEst[1]);
			System.out.print("\t"+format(heurEst));
			System.out.print("\t"+format(gevEst));
			System.out.print("\n");
		}
	}


	public double[] getEsBounds()
	{
		return esEst;
	}

	public double[] getARIMABounds()
	{
		return arimaEst;
	}

	public double getGEVBound()
	{
		return gevEst;
	}

	public double getHeuristicBound()
	{
		return heurEst;
	}

	private boolean isOutsideBounds(double measurement)
	{
		boolean result = false;

		if((measurement < this.updateACET[0])||(measurement > this.updateACET[1]))
		{
			result = true;
		}

		if(measurement > updateWCET)
		{
			result = true;
		}

		return result;
	}


	public void setACETUpdateBounds(double[] bounds)
	{
		updateACET = bounds;
	}

	public void setWCETUpdateBounds(double bounds)
	{
		updateWCET = bounds;
	}


        /**
     * This function formats double values to remove some of the
     * trailing fraction digits. The NumberFormat class is not
     * available in J2ME, so this fulfills a similar role
     *
     * @param value The double value to be formatted
     * @return A string value with only 4 fraction digits
     */
    public String format(double value)
    {
        String response;
        String token;

        try
        {
            token = Double.toString(value);
            if(token.length() > 4)
            {
                response = token.substring(0, 5);
            }
            else
            {
                response = token;
            }
        }
        catch(Exception ex)
        {
            response = "NaN";
        }

        return response;
    }
}
