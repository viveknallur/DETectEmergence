public class WCETData
{
	private int[] frequency;
	private int[] cdf;

	private int exceededMax;
	private int totalMeasurements;

	private int frequencyTotal;
	private int capacity, range;
	private double minValue;
	private double maxValue;
	private boolean updated;

	private int[] paretoCDF;
	private double paretoMin;

	public WCETData()
	{
		range = 0;
		capacity = 100;

		//The min and max of the arrays
		minValue = 0;
		maxValue = 0;

		//Used to count the number of exdeedances
		exceededMax = 0;
		totalMeasurements = 0;

		frequencyTotal = 0;
		updated = false;
	}


	public void updateData()
	{
		generateCDF();
		generateParetoCDF();
	}

	/**
	 * Used to reset the capacity of the array. Note that
	 * no 'smart' dynamic re-sizing of existing arrays is
	 * performed, the capacity variable is just reset.
	 *
	 * @param capacity An int giving the capacity value.
	 */
	public void setCapacity(int capacity)
	{
		this.capacity = capacity;
	}

	public void addMeasurement(double measurement)
	{
		double rounded = Math.rint(measurement);
		updated = true;

		if(totalMeasurements == 0)
		{
			frequency = new int[1];
			frequency[0] = 1;
			minValue = rounded;
			maxValue = rounded;
			range = 0;
		}
		else
		{
			checkExceedance(rounded);
			extendSort(rounded);
		}

		totalMeasurements++;
	}


	private void checkExceedance(double measurement)
	{
		if(measurement > maxValue)
		{
			//Note the exceedance
			exceededMax++;
		}
	}

	private void extendSort(double measurement)
	{
		if(measurement > maxValue)
		{
			//Extend the array to include the new measurement
			double diff = measurement - maxValue;
			extendArrayRight(diff);
			maxValue = measurement;


			//Chop the array if its range is > capacity
			if(frequency.length > capacity)
			{
				minValue = minValue+diff;
				chopArray();
			}
		}
		else if(measurement < minValue)
		{
			//Extend the array to include the new measurement
			double diff = minValue - measurement;
			extendArrayLeft(diff);

			//Chop the array if its range is > capacity
			if(frequency.length > capacity)
			{
				minValue = maxValue - ((double) capacity);
				chopArray();
			}
			else
			{
				minValue = minValue-diff;
			}
		}
		else
		{
			int index = getIndexOf(measurement);
			frequency[index]++;
		}
	}



	/**
	 * This function is used to find the index position within the array, i.e.,
	 * either the PDF or CDF if the number of recorded measurements exceeds the
	 * size of the array. There is an assumption that the measurement value provided
	 * has been already rounded.
	 *
	 * @param measurement The value of the measurement
	 * @return The index position of the element.
	 */
	public int getIndexOf(double measurement)
	{
		if(measurement >= maxValue)
		{
			return (frequency.length-1);
		}
		else if (measurement <= minValue)
		{
			return 0;
		}
		else
		{
			double len = (double) frequency.length;
			double pos = Math.rint(len*(measurement-minValue))/(maxValue-minValue);
			return (int) pos;
		}
	}


	private void extendArrayRight(double diff)
	{
		int num = (int) diff;
		int len = frequency.length;
		int[] temp = new int[len+num];
		temp[len+num-1] = 1;
		System.arraycopy(frequency, 0, temp, 0, len);
		frequency = new int[len+num];
		System.arraycopy(temp, 0, frequency, 0, len+num);
		//int range = len+num;
	}


	private void extendArrayLeft(double diff)
	{
		int num = (int) diff;
		int len = frequency.length;
		int[] temp = new int[len+num];
		temp[0] = 1;
		System.arraycopy(frequency, 0, temp, num, len);
		frequency = new int[len+num];
		System.arraycopy(temp, 0, frequency, 0, len+num);
		//int range = len+num;
	}

	private void chopArray()
	{
		int[] temp = new int[capacity];
		int diff = frequency.length - capacity;

		System.arraycopy(frequency, diff, temp, 0, capacity);

		temp[0] = 0;

		//Tote up all the previous terms
		for(int i=0; i<diff; i++)
		{
			temp[0] += frequency[i];
		}

		frequency = new int[capacity];
		System.arraycopy(temp, 0, frequency, 0, capacity);
		range = capacity;
	}

	/**
	 * This function converts from f(x), the probability value,
	 * to x, the actual value of the measurements.
	 *
	 * @param prob The probability value, between 0.0 and 1.0.
	 * @return The value of the measurement at that probability value.
	 */
	public double getMeasurementCDF(double prob)
	{
		if(prob == 0.0)
		{
			return minValue;
		}
		else if(prob > 0.0 && prob <= 1.0)
		{
			double index = (double) frequency.length;
			index = Math.rint(prob*index);
			return (minValue+index);
		}
		else
		{
			return -1.0;
		}
	}


	/**
	 * This function is used to generate a CDF function from the
	 * existing frequency distribution. Essentially this function
	 * sums all the values in the frequency distribution.
	 *
	 */
	public void generateCDF()
	{
		cdf = new int[frequency.length];
		frequencyTotal = 0;

		for(int i=0; i<frequency.length; i++)
		{
			frequencyTotal += frequency[i];
			cdf[i] = frequencyTotal;
		}

		//Set the flat to avoid unnecessary calls to
		//the generateCDF function again.
		updated = false;
	}

	/**
	 * This function is used to generate a specific CDF for the
	 * pareto distribution, such that only values greater than
	 * the maximum frequency position are used, e.g. the right
	 * hand decreasing side of a normal curve.
	 */
	public void generateParetoCDF()
	{
		int max = 0;
		int maxIndex = -1;

		for(int i=0; i<frequency.length; i++)
		{
			if(frequency[i] > max)
			{
				max = frequency[i];
				maxIndex = i;
			}
		}

		paretoCDF = new int[frequency.length-maxIndex];
		paretoMin = minValue + (double) maxIndex;

		//System.err.println("Resizing Pareto Array: "+paretoCDF.length);

		int total = 0;

		for(int i=0; i<paretoCDF.length; i++)
		{
			total += frequency[i+maxIndex];
			paretoCDF[i] = total;
		}
	}

	public double getParetoMin()
	{
		return paretoMin;
	}

	public double getParetoCDF(double prob)
	{
		if(prob == 0.0)
		{
			return paretoMin;
		}
		else if(prob > 0.0 && prob <= 1.0)
		{
			double index = (double) paretoCDF.length;
			index = Math.rint(prob*index);
			return (paretoMin+index);
		}
		else
		{
			return -1.0;
		}
	}

	/**
	 * This function returns the probability value, otherwise known
	 * as f(x), or the vertical axis of the CDF. This probabilty is
	 * taken from the index position specified within the CDF.
	 * To find the f(x) for a particular value of x, use the
	 * function getCDF() instead.
	 *
	 * @param index
	 * @return
	 */
	public double getCDFProb(int index)
	{
		//Check to see if cdf needs to be updated
		if(updated)
		{
			generateCDF();
		}

		//Return the cdf for that index position
		double num = (double) cdf[index];
		double denom = (double) frequencyTotal;
		return (num/denom);
	}


	public double getCDF(double measurement)
	{
		if(measurement >= minValue && measurement <= maxValue)
		{
			if(updated)
			{
				generateCDF();
			}

			int index = this.getIndexOf(measurement);
			double cdfValue = (double) cdf[index];
			return (cdfValue/frequencyTotal);
		}
		else
		{
			return 0.0;
		}
	}


	public void printCDF()
	{
		generateCDF();

		for(int i=0; i<cdf.length; i++)
		{
			double value = getCDFProb(i);
			System.out.println((minValue+i)+"\t"+value+"\t"+frequency[i]);
		}
	}


	public int getSize()
	{
		return totalMeasurements;
	}

	public int getRange()
	{
		return (int) (maxValue-minValue);
	}

	public int getFrequency(double measurement)
	{
		if((measurement < minValue))
		{
			return 0;
		}
		else if(measurement > maxValue)
		{
			return 0;
		}
		else
		{
			int index = getIndexOf(measurement);
			return frequency[index];
		}
	}

	public int getFrequencyIndex(int index)
	{
		return frequency[index];
	}

	public int getFrequencyLength()
	{
		return frequency.length;
	}

	public double getMinValue()
	{
		return minValue;
	}

	public double getMaxValue()
	{
		return maxValue;
	}

	public int getCDFLength()
	{
		return cdf.length;
	}


	public double getExceededRatio()
	{
		double m = (double) exceededMax;
		double n = (double) totalMeasurements;
		return (n/(n+m));
	}

	public double getQuartile(int quartile)
	{
		if(quartile == 0)
		{
			return minValue;
		}
		else if(quartile == 1)
		{
			return (0.25*(minValue+maxValue));
		}
		else if(quartile == 2)
		{
			return (0.5*(minValue+maxValue));
		}
		else if(quartile == 3)
		{
			return (0.75*(minValue+maxValue));
		}
		else if(quartile == 4)
		{
			return maxValue;
		}
		else
		{
			return 0.0;
		}
	}
}
